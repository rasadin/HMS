<center>
<section id="doctors">
<h2 class="btn btn-primary btn-lg"><center><b>OUR DOCTORS</b></center></h2>
<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
       <div class="row">
    <div class="col">
      <a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	  <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center>
	 
        </div>

    <div class="col">
<a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	   <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center>     
       </div>

      
    <div class="col">
<a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	   <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center> 
 </div>

       </div>
    </div>
    <div class="carousel-item">
      <div class="row">
    <div class="col">
<a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	   <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center>   
   </div>

    <div class="col">
<a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	   <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center>      
       </div>

      
    <div class="col">
<a href="D2.php"> <img src="img/d1.jpg" alt="Los Angeles" ></a>
	  <br>
	   <center><a href="D2.php" class="btn btn-success">JESMIN AKTHER</a></center>
	 <center><a href="D2.php" class="btn btn-success">RESPIRATORY MEDICINE SPECIALIST</a></center>
      </div>

       </div>
      
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
</section>
</center>
	
	
	
	
	
	
<section id="departments">
<div class="container">
<h2 class="btn btn-primary btn-lg"><center><b>OUR DEPARTMENTS</b></center></h2>
<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="pill" href="#General_Surgery" class="btn btn-success">General Surgery</a></li>
    <li><a data-toggle="pill" href="#Gynaecology"class="btn btn-success">Gynaecology</a></li>
    <li><a data-toggle="pill" href="#Microbiology"class="btn btn-success">Microbiology</a></li>
    <li><a data-toggle="pill" href="#Neonatal"class="btn btn-success">Neonatal</a></li>
    <li><a data-toggle="pill" href="#Nephrology"class="btn btn-success">Nephrology</a></li>
    <li><a data-toggle="pill" href="#Neurology"class="btn btn-success">Neurology</a></li>
	<li><a data-toggle="pill" href="#Obstetrics"class="btn btn-success">Obstetrics</a></li>
    <li><a data-toggle="pill" href="#Oncology"class="btn btn-success">Oncology</a></li>
    <li><a data-toggle="pill" href="#Orthopaedics"class="btn btn-success">Orthopaedics</a></li>
    <li><a data-toggle="pill" href="#Pharmacy"class="btn btn-success">Pharmacy</a></li>
    <li><a data-toggle="pill" href="#Radiotherapy"class="btn btn-success">Radiotherapy</a></li>
    <li><a data-toggle="pill" href="#Rheumatology"class="btn btn-success">Rheumatology</a></li>
</ul>
 <div class="tab-content">
 <div class="active" >
<center><img src="img/d.jpg" alt="Los Angeles" ></center>
</div>
<div id="General_Surgery" class="tab-pane fade" >
  <button type="button" class="btn btn-danger">General Surgery</button>
<p>General_Surgery. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
</div>
<div id="Gynaecology" class="tab-pane fade">
<button type="button" class="btn btn-danger">Gynaecology</button>

      <p>Gynaecology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals</p>
    </div>
    <div id="Microbiology" class="tab-pane fade">
	<button type="button" class="btn btn-danger">Microbiology</button>

      <p>Microbiology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals</p>
    </div>
    <div id="Neonatal" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Neonatal</button>

      <p>A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Nephrology" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Nephrology</button>
      <p>Nephrology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Neurology" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Neurology</button>
      <p>Neurology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Obstetrics" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Obstetrics</button>
      <p>Obstetrics. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Oncology" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Oncology</button>
      <p>Oncology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Orthopaedics" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Orthopaedics</button>
      <p>Orthopaedics. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Pharmacy" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Pharmacy</button>
      <p>Pharmacy.A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Radiotherapy" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Radiotherapy</button>
      <p>Radiotherapy.A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
	<div id="Rheumatology" class="tab-pane fade">
      	<button type="button" class="btn btn-danger">Rheumatology</button>
      <p>Rheumatology. A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a heart attack. A district hospital typically is the major health care facility in its region, with large numbers of beds for intensive care and additional beds for patients who need long-term care. Specialised hospitals include trauma centres, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. Specialised hospitals can help reduce health care costs compared to general hospitals.</p>
    </div>
  </div>
</div>
</section>
<section id="about">
<div class="container">
<div class="row">
<div class="col-sm-6 col-md-6 hidden-xs hidden-sm">
<img src="img/about0.jpg" class="img-responsive" alt="">
</div>
<div class="col-sm-12 col-md-6">
<div class="about-des"> 
<h3 class="btn btn-primary btn-lg">ABOUT US</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ipsum magna, gravida nec erat ac, malesuada pharetra felis. Phasellus eu dolor orci. Duis et dictum sem, sit amet sagittis dolor. Curabitur scelerisque, nunc eget viverra malesuada, nunc ligulaâ€¦&#8230;</p>
<a href="about_more.php" class="btn btn-success">Read More</a>
<hr>
<h3 class="btn btn-primary btn-lg">OUR VISION & MISSION</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ipsum magna, gravida nec erat ac, malesuada pharetra felis. Phasellus eu dolor orci. Duis et dictum sem, sit amet sagittis dolor. Curabitur scelerisque, nunc eget viverra malesuada, nunc ligula.Lorem&#8230;</p>
<a href="vision_more.php" class="btn btn-success">Read More</a>
<hr>
</div>
</div>
</div>
</div>
</section>


<!-- Service Section -->
<section id="services">
<div class="container">
<div class="row">
<!-- Main Title -->
<div class="col-md-6 col-md-offset-3">
<div class="title-block">
<br>
<br>
<button type="button" class="btn btn-primary btn-lg">Service We Offer</button>
<br>
<br>

</div>
</div>
</div>
<div class="row" id="service-content">
<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s2.png" alt="" class="hvr-buzz-out"/>

</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Service We Offer</button>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦</p>
</div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s3.png" alt="" class="hvr-buzz-out"/>
</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Ophthalmology</button>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦</p>
</div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s4.png" alt="" class="hvr-buzz-out"/>

</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Medicine</button>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦&#8230;</p>
</div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s1.png" alt="" class="hvr-buzz-out"/>

</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Hospital</button>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦&#8230;</p>
</div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s6.png" alt="" class="hvr-buzz-out"/>

</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Health Service</button>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦&#8230;</p>
</div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="service-grid">
<div class="service-icon">
<img src="s5.png" alt="" class="hvr-buzz-out"/>

</div>
<div class="service-text" >
<button type="button" class="btn btn-warning">Medical kit</button>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum non tellus quis ante vulputate mattis vitae id erat.â€¦&#8230;</p>
</div>
</div>
</div>


</div>
</div>
</section> 
<section id="contact">
<center><h3 class="btn btn-primary btn-lg">CONTACT WITH US</h3></center>
<br> <br> <br>
<center>
<div class="row">
<!-- BLANK SPACE -->
<div class="col-sm-1">
</div>
<!-- Enquiry -->
<?php
   if($_POST)                         
   {
   
     $name = $_POST['name'];
      $email = $_POST['email'];
      $mobile = $_POST['mobile'];
      $enquiry = $_POST['enquiry'];
      
    
      
   
    
            $con = mysqli_connect("localhost", "root", "", "hms");
   
   
   if($con === false){
      die("ERROR: Could not connect. " . mysqli_connect_error());
   }
    $sql = "INSERT INTO enquiry (fullname, email, mobile, enquiry) VALUES ('$name', '$email', '$mobile', '$enquiry')";
   
   if($result = mysqli_query($con, $sql)){
              // echo "<h5>Data inserted</h5>";
            } else{
               echo "<p>Already Exist!</p>";
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
            }
            mysqli_close($con);
         }
         
   
   ?>
<div class="col-sm-3"> 
<form action="" id="enquiryForm" method="post" accept-charset="utf-8">
<button type="button" class="btn btn-danger">Enquiry Form</button>
<input type="hidden" name="csrf_stream_token" value="23a09478dc7e3bf441c2034982139e94" />                                                     
                  <div class="form-group">
                    <input type="name" name="name" class="form-control" placeholder="Full Name">
                  </div>
                  <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="Email Address">
                  </div>
                  <div class="form-group">
                    <input type="phone" name="mobile" class="form-control" placeholder="Phone No">
                  </div>
                  <div class="form-group">
                    <textarea name="enquiry" class="form-control" placeholder="Enquiry"></textarea> 
                  </div> 
                  <div class="form-group"> 
                    <button type="submit" class="thm-btn page-scroll pull-right">Submit</button>
                  </div>  
                </form>         
				</div>   

				
				
     
            <!-- Address -->
<div class="col-sm-3">                 <div class="footer-box address-inner">
                    <img src="img/hospital.jpg" alt="">
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration&#8230;</p>
                    <div class="address">
                                                <i class="flaticon-placeholder"></i>
                        <p>&#9962 123/A, Street, State-12345, Demo</p>
                                            </div>
                    <div class="address">
                                                <i class="flaticon-customer-service"></i>
                        <p>&#9742 0123456788</p>
                                            </div>
                    <div class="address">
                                                <i class="flaticon-mail"></i>
                        <p> <button type="button" class="btn btn-info">&#9997 hospital@gmail.com</button> </p>
                                            </div>
                </div>
            </div>

      
            

            
            <!-- Map -->
            <div class="col-sm-3"> 
                <div class="map">
                   <button type="button" class="btn btn-success">Google Map</button>
                    <div id="map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.4016169203146!2d90.42351411435888!3d23.768708793994882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7894ad2a21d%3A0xbb20a6f3fc4db34a!2sEast+West+University+(EWU)!5e0!3m2!1sen!2sbd!4v1511536482120" width="300" height="250" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                </div>
            </div>
        </div>
    </div>
</center> 
</section>