<?php
//Create connection 
$con = mysqli_connect('localhost', 'root', '', 'hms');

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT departmentname FROM department";

$result = mysqli_query($con, $sql);
?>


<!DOCTYPE html>
<html>
   <head>
      <title>Appointment</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
      <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
      <style type="text/css">
         p{
         color: red;
         }
         h5{
         color: green;
         }
      </style>
   </head>
   <body>
      <div style="margin: 0px auto; width: 500px;padding: 50px;">
         <!-- Nav tabs -->
         <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
               <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Get Patient Id</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Appointment</a>
            </li>
         </ul>
         <!-- Tab panes -->
         <div class="tab-content">
            <div class="tab-pane active" id="home" role="tabpanel">
              
               <?php
         if ($_POST) {
         
                                   $errors = array();
                                   
                                   if (empty($_POST['firstname'])) {
                                       $errors['firstname'] = "First Name is required!";
                                   }
                                   if (empty($_POST['lastname'])) {
                                       $errors['lastname'] = "Last Name is required!";
                                   }
                                   if (empty($_POST['email'])) {
                                       $errors['email'] = "Email is required!";
                                   }
                                   if (empty($_POST['password'])) {
                                       $errors['password'] = "Password is required!";
                                   }
                                   if (!isset($_POST['sex'])) {
                                       $errors['sex'] = "Sex must be selected!";
                                   }
                                   if (empty($_POST['mobile'])) {
                                       $errors['mobile'] = "Mobile is required!";
                                   }
                                   if (empty($_POST['dob'])) {
                                       $errors['dob'] = "Date of Birth is required!";
                                   }
                                   if (empty($_POST['bloodgroup'])) {
                                       $errors['bloodgroup'] = "Blood Group is required!";
                                   }
                                   if (empty($_POST['picture'])) {
                                       $errors['picture'] = "Picture is required!";
                                   }
                                   if (empty($_POST['document'])) {
                                       $errors['document'] = "Document is required!";
                                   }
                                   if (empty($_POST['address'])) {
                                       $errors['address'] = "Address is required!";
                                   }
         
         
         
                if (count($errors) == 0) {                   
                $firstname = $_POST['firstname'];
                $lastname = $_POST['lastname'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $mobile = $_POST['mobile'];
                $sex = $_POST['sex'];
                $dob = $_POST['dob'];
                $bloodgroup = $_POST['bloodgroup'];
                $picture = $_POST['picture'];
                $document = $_POST['document'];
                $address = $_POST['address'];
         
         
         
            
            
         
            $con = mysqli_connect("localhost", "root", "", "hms");
             
         
            if($con === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            } 
         
            $sql = "INSERT INTO patient (firstname, lastname, email, password, mobile, sex, dateofbirth, bloodgroup, picture, documents, address) VALUES ('$firstname', '$lastname', '$email', '$password', '$mobile', '$sex', '$dob', '$bloodgroup', '$picture', '$document', '$address')";
            if($result = mysqli_query($con, $sql)){
               echo "<h5>Data inserted</h5>";
            } else{
               echo "<p>Already Exist!</p>";
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
            }
            mysqli_close($con);
         }
         }
         ?>
               <form action="" method="post">
                  <div class="form-group">
                     <label for="fistname">First Name:</label>
                     <input type="text" class="form-control" name="firstname" placeholder="Write your First Name" value="<?php if(isset($_POST['firstname'])) echo $_POST['firstname']; ?>">
                     <p><?php if(isset($errors['firstname'])) echo $errors['firstname']; ?></p>
                  </div>
                  <div class="form-group">
                     <label for="lastname">Last Name:</label>
                     <input type="text" class="form-control" name="lastname" placeholder="Write your Last Name" value="<?php if(isset($_POST['lastname'])) echo $_POST['lastname']; ?>">
                     <p><?php if(isset($errors['lastname'])) echo $errors['lastname']; ?></p>
                  </div>
                  <div class="form-group">
                     <label for="email">Email:</label>
                     <input type="text" class="form-control" name="email" placeholder="Write your Email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>">
                     <p><?php if(isset($errors['email'])) echo $errors['email']; ?></p>
                  </div>
                  <div class="form-group">
                     <label for="password">Password:</label>
                     <input type="password" class="form-control" name="password" value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>">
                     <p><?php if(isset($errors['password'])) echo $errors['password']; ?></p>
                  </div>
                  <div class="form-group">
                     <label for="fistname">Contact:</label>
                     <input type="text" class="form-control" name="mobile" placeholder="Mobile Number">
                  </div>
                  <div class="radio">
                     <label>Sex:</label>
                     <label class="radio-inline"><input type="radio" name="sex" value="Male">Male</label>
                     <label class="radio-inline"><input type="radio" name="sex" value="Female">Female</label>
                     <p><?php if(isset($errors['sex'])) echo $errors['sex']; ?></p>
                  </div>
                  <div class="form-group">
                     <label for="example-date-input">Date of Birth:</label>
                     <input class="form-control" type="date" value="" id="example-date-input">
                  </div>
                  <div class="form-group">
                     <label for="sel1">Blood Group:</label>
                     <select class="form-control" id="sel1">
                        <option>Select Option</option>
                        <option>A+</option>
                        <option>A-</option>
                        <option>B+</option>
                        <option>B-</option>
                        <option>O+</option>
                        <option>O-</option>
                        <option>AB+</option>
                        <option>AB-</option>
                     </select>
                  </div>
                  <div class="form-group">
                     <label for="exampleInputFile">Picture:</label>
                     <input type="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
                  </div>
                  <div class="form-group">
                     <label for="exampleInputFile">Add Documents (optional): </label>
                     <input type="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
                  </div>
                  <div class="form-group">
                     <label for="exampleTextarea">Address:</label>
                     <textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
                  </div>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                  <button type="submit" class="btn btn-primary">Submit</button>
               </form>
            </div>
            <div class="tab-pane" id="profile" role="tabpanel">
               <form>
                  <div class="form-group">
                     <label for="patientid">Patient ID:</label>
                     <input type="text" class="form-control" name="patientid" placeholder="Patient Id">
                  </div>
                  <div class="form-group">
                     <label for="sel1">Department Name:</label>
                     <select class="form-control" id="sel1" name="departmentname">
                        <option value="0">Select Department</option>
                        <?php
                           while ($row = mysqli_fetch_assoc($result)) {
                           ?>
                        <option value = "<?php echo ($row['departmentname']);?>" >
                           <?php echo ($row['departmentname']);?>
                        </option>
                        <?php
                           }?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label for="sel1">Doctor Name:</label>
                     <select class="form-control" id="sel1">
                        <option>Select Doctor Name</option>
                        <option>....</option>
                        <option>...</option>
                     </select>
                  </div>
                  <div class="form-group">
                     <label for="example-date-input">Appointment Date:</label>
                     <input class="form-control" type="date" value="" id="example-date-input">
                  </div>
                  <div class="form-group">
                     <label for="exampleTextarea">Problem:</label>
                     <textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
                  </div>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                  <button type="submit" class="btn btn-primary">Submit</button>
               </form>
            </div>
         </div>
      </div>
   </body>
</html>