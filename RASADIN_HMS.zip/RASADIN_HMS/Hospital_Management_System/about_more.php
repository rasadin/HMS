<!DOCTYPE HTML>
<html>
<head>
<title>
RASADIN
</title>
<style>
p5 {
    font-size: 18px;
	color: #ffffff;
	text-align: center;	
}
p1 {
    font-size: 80px;
	color: #4d0000;
}
p2{
font-size: 20px;
}
p4{
font-size: 40px;
 color: #ffffff;

}

#div1{
  width:40%;
  height:600px;
  float:left;
  color: #ffffff;
  margin: NONE;
  background: #660066;

}
#div2{
  width:60%;
  height:600px;
  float:right;
  color: red;
  margin: red;
  background: gray;
}
img{
    float: center;
    margin: 0 0 0px 0px;
    border: 3px solid black;
}

#contact{
border: 3px solid black;
background-color: gray;
color:#ffffff
}
a:link {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: pink;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: red;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: yellow;
    background-color: transparent;
    text-decoration: underline;
}



</style>
</head>
<body>
<div>
<center>
<p1><b>ABOUT US</b></p1><br>
<p2></p2>
</center>
</div>


<div id="div1">
<center>

<center><b>ABOUT US</b></center>
<br>
First, there has been an increase in cache capacity. There are now typically two or three levels of cache between the processor and main memory. As chip density has increased, more of the cache memory has been incorporated on the chip, enabling faster cache access. For example, the original Pentium chip devoted about 10% of on-chip area to a cache. The most recent Pentium 4 chip devotes about half of the chip area to caches. Second, the instruction execution logic within a processor has become increasingly complex to enable parallel execution of instructions within the processor. Two noteworthy design approaches have been pipelining and superscalar. A pipeline works much as an assembly line in a manufacturing plant enabling different stages of execution of different instructions to occur at the same time along the pipeline. A superscalar approach in essence allows multiple pipelines within a single processor so that instructions that do not depend on one another can be executed in parallel. Both of these approaches are reaching a point of diminishing returns. The internal organization of contemporary processors is exceedingly complex and is able to squeeze a great deal of parallelism out of the instruction stream. It seems likely that further significant increases in this direction will be relatively modest [GIBB04].With three levels of cache on the processor chip, each level providing substantial capacity; it also seems that the benefits from the cache are reaching a limit. However, simply relying on increasing clock rate for increased performance runs into the power dissipation problem already referred to. The faster the clock rate, the greater the amount of power to be dissipated and some fundamental physical limits are being reached. With all of these difficulties in mind, designers have turned to a fundamentally new approach to improving performance: placing multiple processors on the same chip, with a large shared cache. The use of multiple processors on the same chip, also referred to as multiple cores, or multicore, provides the potential to increase performance without increasing the clock rate. Studies indicate that, within a processor, the increase in performance is roughly proportional to the square root of the increase in complexity [BORK03].
</center>
</div>

<div id="div2">

<center>
<p><img src="img/more1.jpg" alt="rasadin's image" style="width:99%;height:100%;"></p>

</center>


<footer style="background-color: #0144af"; >
  <center> <p5><a href="https://www.facebook.com/mohammad.rasadin" target="_blank">&copy HMS HOSPITAL</a>,&nbsp All Rights Reserved.</p5></center>
</footer>
</div>

</body>
</html>
